# Île Perdue — Survie

## Jouer tout de suite
Ouvre `index.html` dans un navigateur récent. Le jeu fonctionne avec les boutons tactiles et aussi avec les flèches + espace sur ordinateur.

## Installer comme une application sur téléphone
Pour qu'un navigateur propose **Ajouter à l'écran d'accueil / Installer**, les fichiers PWA doivent être publiés sur une adresse HTTPS.
1. Décompresse ce dossier.
2. Publie son contenu sur un hébergement statique HTTPS (par exemple GitHub Pages).
3. Ouvre l'adresse HTTPS sur ton téléphone.
4. Dans le menu du navigateur, choisis **Ajouter à l'écran d'accueil** ou **Installer l'application**.

Le jeu ne demande aucun compte et ne collecte aucune donnée. Une fois installé et mis en cache, il peut fonctionner hors ligne.
